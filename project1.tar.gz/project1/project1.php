<html>
 <head>
  <title>Test PHP</title>
 </head>
 <body>
 <?php echo '<p>Bonjour Anthony</p>'; ?>
 </body>
</html>
